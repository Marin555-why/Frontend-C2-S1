import Stats from "./Stats";
export default function Scores({ courseName, courseResults }) {
    
       function getScores(score) {
        return score < 50 ? "warning" : "";
       }
    return(
        <section className="scores">
            <h1>{courseName}</h1>
            <table>
            <thead>
              <tr>
                <th>First name</th>
                <th>Last name</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>First name 1 </td>
                <td>Last name 1 </td>
                <td>55</td>
              </tr>
              <tr>
                <td>First name 2 </td>
                <td>Last name 2 </td>
                <td>45</td>
              </tr>
          {courseResults.map((student, index) => (
            <tr key={index}>
              <td>{student.firstName}</td>
              <td>{student.lastName}</td>
              <td className={getScores(student.score)}>
                {student.score}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <Stats courseResults={courseResults} />
            
        </section>   
    
    );
}

   