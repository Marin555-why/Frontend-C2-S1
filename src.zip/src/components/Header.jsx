
export default function Header({batchName}) {
const pnlogo = "./public/pn-logo.png";
return (
    <header id="header">
      <img src={pnlogo} alt="PN Logo" />
      <h1>Students results for {batchName}</h1>
    </header>
  );
}