export default function Stats({courseResults}) {
    const scores = courseResults.map(student => student.score);
    const average = (scores.reduce((a,b) => a+b, 0 / scores.length)).toFixed(2);
    const min = Math.min(...scores);
    const max = Math.max(...scores);
    return(
        <div className = 'stats'>
            <p>Average:{average}</p>
            <p>Min.:{min}</p>
            <p>Max.:{max}</p>
        </div>
    );

}
