import Header from "./components/Header";
import { JAVA_RESULTS, PYTHON_RESULTS, HTML_RESULTS, ENGLISH_RESULTS } from "./data";
import Scores from "./components/Scores";
function App() {
  return (
    <>
      <Header batchName = "Student Results For Batch PNC 2024"/>
      
      <main className = "score-container">
        <Scores courseName = "Java" courseResults={JAVA_RESULTS}/>
        <Scores courseName = "Python" courseResults={PYTHON_RESULTS}/>
        <Scores courseName = "HTML" courseResults={HTML_RESULTS}/>
        <Scores courseName = "English" courseResults={ENGLISH_RESULTS}/>
      </main>
    </>
  );
}

export default App;
